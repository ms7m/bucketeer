
version = {
    "major": 0,
    "minor": 1,
    "patch": 5
}

version_str = f"{version['major']}.{version['minor']}.{version['patch']}"