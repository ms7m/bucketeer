
class KeyLookupAdditionCountFailure(Exception):
    pass

class KeyLookupSubtractionCountFailure(Exception):
    pass

class KeyRetrievalFailure(Exception):
    pass